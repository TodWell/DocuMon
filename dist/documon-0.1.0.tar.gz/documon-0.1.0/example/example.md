# Module: example

Bla bla bal



## Elements

- Functions  
- Classes  
- Properties  
- Modules  
  - [example.example_py](example\example_py.md): Bla bal  
    - Functions  
      - [some_fun_function(...)](example\example_py\some_fun_function.md): Anything  
        - Arguments  
          - a: input a  
            - Type: `str`  
          - b: input b  
            - Type: `float`  
        - Additional Arguments:  
          - Type: `_empty`  
    - Classes  
      - [SomeClass](example\example_py\SomeClass.md): Further description  
        - **Properties:**  
          - a: Initial value: 1  
          - aa (property): Property description  
        - **Methods:**  
          - [return_a(...)](example\example_py\SomeClass.return_a.md): hey  
        - **InnerClasses:**  
          - [Innter](example\example_py\SomeClass.Innter.md):   
            - **Properties:**  
            - **Methods:**  
            - **InnerClasses:**  
      - [SomeSubclass](example\example_py\SomeSubclass.md):   
        - **Properties:**  
          - a: Initial value: 1  
          - aa (property): Property description  
        - **Methods:**  
          - [return_a(...)](example\example_py\SomeSubclass.return_a.md): hey  
          - [return_b(...)](example\example_py\SomeSubclass.return_b.md):   
        - **InnerClasses:**  
          - [Innter](example\example_py\SomeClass.Innter.md):   
            - **Properties:**  
            - **Methods:**  
            - **InnerClasses:**  
    - Properties  
    - Modules  
  - [example.run](example\run.md):   
    - Functions  
    - Classes  
    - Properties  
    - Modules  
  - [example.test](example\test.md):   
    - Functions  
    - Classes  
    - Properties  
    - Modules  
