from DocuMon.core.elements.module import ModuleD
from DocuMon.core.types import ModuleT
from DocuMon.core.utils.reader import LineReader


def process_module(module: ModuleT):
    mod = ModuleD(
        module
    )


def process_file():
    pass


def process_function():
    pass


def process_class():
    pass